from data.loader import bot

import handlers

if __name__ == '__main__':
    bot.infinity_polling()

